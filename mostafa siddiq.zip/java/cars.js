$(document).ready(function()
{
$("#appear1").click (function()
{
$(".example-one").toggle(2000);
});
});


$(document).ready(function()
{
$("#appear2").click (function()
{
$(".example-2").toggle(2000);
});
});


$(document).ready(function()
{
$("#appear3").click (function()
{
$(".example-3").toggle(2000);
});
});